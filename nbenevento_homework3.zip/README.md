# nlp_assignment_3

## Run Instructions
1. Ensure that sklearn is installed. 
1. Run the command `pip install -r reqs.txt` to install required libraries.
1. Run the homework script: `python homework3.py`

